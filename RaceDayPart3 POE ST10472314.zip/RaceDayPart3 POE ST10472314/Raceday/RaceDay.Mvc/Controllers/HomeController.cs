using Microsoft.AspNetCore.Mvc;using Microsoft.AspNetCore.Authorization;using RaceDay.Mvc.Models;using RaceDay.Mvc.Services;
namespace RaceDay.Mvc.Controllers;
public class HomeController(RaceDayApiClient api):Controller{
 [AllowAnonymous] public async Task<IActionResult> Index(){if(User.Identity?.IsAuthenticated==true)return RedirectToAction("Index",User.IsInRole("Organiser")?"Organiser":"Participant");try{ViewBag.Events=await api.Get<List<EventDto>>("api/events")??[];}catch{ViewBag.Events=new List<EventDto>();}return View();}
 [AllowAnonymous] public IActionResult Error()=>View();
}
