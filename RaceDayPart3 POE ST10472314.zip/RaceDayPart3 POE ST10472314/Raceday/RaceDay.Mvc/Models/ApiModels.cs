using System.ComponentModel.DataAnnotations;
namespace RaceDay.Mvc.Models;
public record ApiUser(int UserID,string FirstName,string LastName,string Email,string Role,string CreatedAt,string? ProfileImageUrl=null);
public record AuthResponse(string AccessToken,string TokenType,DateTime ExpiresAt,ApiUser User);
public record LoginModel([Required,EmailAddress] string Email,[Required] string Password);
public record RegisterModel([Required,MaxLength(100)] string FirstName,[Required,MaxLength(100)] string LastName,[Required,EmailAddress] string Email,[Required,MinLength(8)] string Password);
public record EventDto(int EventID,string EventName,string? Description,DateTime EventDate,string Location,string Status,int OrganiserID,string? BannerImageUrl=null);
public record EventInput([Required,MaxLength(200)] string EventName,string? Description,[Required] DateTime EventDate,[Required,MaxLength(255)] string Location);
public record CategoryDto(int CategoryID,string CategoryName,decimal DistanceKm,int CreatedByUserID);
public record CategoryInput([Required,MaxLength(150)] string CategoryName,[Range(typeof(decimal),"0.01","9999")] decimal DistanceKm);
public record OfferingDto(int EventID,int CategoryID,string EventName,string CategoryName,decimal DistanceKm,decimal EntryFee,int Capacity,int ConfirmedEnrolments);
public record OfferingInput([Range(typeof(decimal),"0","999999")] decimal EntryFee,[Range(1,1000000)] int Capacity);
public record EnrolmentInput([Range(1,int.MaxValue)] int EventID,[Range(1,int.MaxValue)] int CategoryID);
public record EnrolmentDto(int EnrolmentID,int EventID,string EventName,int CategoryID,string CategoryName,int ParticipantID,string ParticipantName,DateTime EnrolmentDate,string Status);
public record ResultInput(TimeSpan? FinishTime,int? Position,[Required] string Status="Recorded");
public record ResultDto(int ResultID,int EnrolmentID,int ParticipantID,string ParticipantName,int EventID,string EventName,string CategoryName,TimeSpan? FinishTime,int? Position,string Status,DateTime RecordedAt);
public class ProfileInput { [Required,MaxLength(100)] public string FirstName{get;set;}=""; [Required,MaxLength(100)] public string LastName{get;set;}=""; [Required,EmailAddress] public string Email{get;set;}=""; }
