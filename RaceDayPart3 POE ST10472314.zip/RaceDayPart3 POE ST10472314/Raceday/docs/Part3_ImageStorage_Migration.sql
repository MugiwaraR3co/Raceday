/* Apply once to an existing RaceDay database. This does NOT drop data. */
IF COL_LENGTH('dbo.Users','ProfileImageUrl') IS NULL
    ALTER TABLE dbo.Users ADD ProfileImageUrl NVARCHAR(2048) NULL;
GO
IF COL_LENGTH('dbo.Events','BannerImageUrl') IS NULL
    ALTER TABLE dbo.Events ADD BannerImageUrl NVARCHAR(2048) NULL;
GO
