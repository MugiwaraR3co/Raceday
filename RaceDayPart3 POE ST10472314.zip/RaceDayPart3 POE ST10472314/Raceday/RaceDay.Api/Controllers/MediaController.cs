using Azure.Storage.Blobs;using Azure.Storage.Blobs.Models;using Microsoft.AspNetCore.Authorization;using Microsoft.AspNetCore.Mvc;using Microsoft.EntityFrameworkCore;using RaceDay.Api.Data;using RaceDay.Api.Models;using RaceDay.Api.Services;
namespace RaceDay.Api.Controllers;
[ApiController,Route("api/media")]
public class MediaController(RaceDayContext db,IConfiguration config):ControllerBase{
 [HttpPost("profile"),Authorize]
 [RequestSizeLimit(5_000_000)]
 public async Task<IActionResult> UploadProfile(IFormFile file){if(!Valid(file))return BadRequest(new{message="Upload a JPG, PNG or WEBP image smaller than 5 MB."});var user=await db.Users.SingleOrDefaultAsync(x=>x.UserID==User.CurrentUserId());if(user is null)return NotFound();var url=await Upload(file,"profile-images",$"user-{user.UserID}");user.ProfileImageUrl=url;await db.SaveChangesAsync();return Ok(new{url});}
 [HttpPost("events/{eventId:int}/banner"),Authorize(Roles="Organiser")]
 [RequestSizeLimit(5_000_000)]
 public async Task<IActionResult> UploadBanner(int eventId,IFormFile file){if(!Valid(file))return BadRequest(new{message="Upload a JPG, PNG or WEBP image smaller than 5 MB."});var e=await db.Events.SingleOrDefaultAsync(x=>x.EventID==eventId);if(e is null)return NotFound();if(e.OrganiserID!=User.CurrentUserId())return Forbid();var url=await Upload(file,"event-banners",$"event-{eventId}");e.BannerImageUrl=url;await db.SaveChangesAsync();return Ok(new{url});}
 private bool Valid(IFormFile f)=>f is not null&&f.Length>0&&f.Length<=5_000_000&&new[]{"image/jpeg","image/png","image/webp"}.Contains(f.ContentType.ToLowerInvariant());
 private async Task<string> Upload(IFormFile file,string container,string prefix){var cs=config["AzureBlobStorage:ConnectionString"];if(string.IsNullOrWhiteSpace(cs))throw new InvalidOperationException("Azure Blob Storage is not configured. Set AzureBlobStorage__ConnectionString.");var service=new BlobServiceClient(cs);var bucket=service.GetBlobContainerClient(container);await bucket.CreateIfNotExistsAsync(PublicAccessType.Blob);var ext=Path.GetExtension(file.FileName).ToLowerInvariant();var blob=bucket.GetBlobClient($"{prefix}-{Guid.NewGuid():N}{ext}");await using var stream=file.OpenReadStream();await blob.UploadAsync(stream,new BlobHttpHeaders{ContentType=file.ContentType});return blob.Uri.ToString();}
}
