# RaceDay Part 3 — MVC Web Application

Part 3 adds a .NET 10 ASP.NET Core MVC frontend to the existing Part 1 + Part 2 solution. MVC consumes the REST API through `RaceDayApiClient`; it does not connect to SQL Server directly.

## Included
- Cookie-based MVC sign-in backed by the Part 2 JWT API. JWT remains in server-side session and is attached to API requests.
- Participant registration, dashboard, event discovery/search, event details, category enrolment, cancellation, own enrolments, own results and profile update.
- Organiser dashboard, event creation/edit/cancellation, category creation, event category offerings, participant/enrolment listing and result capture.
- Bootstrap responsive layout, consistent RaceDay styling, validation and user-friendly API errors.
- Multi-stage Dockerfile and GitHub Actions workflow that restores/builds the full solution and runs Part 2 tests.

## Requirements
Install .NET 10 SDK and Visual Studio 2022 with ASP.NET and web development workload. SQL Server and the Part 2 database must be running. Start the API first and note its HTTPS/HTTP address.

## Configure API address
Edit `RaceDay.Mvc/appsettings.json` and set `Api:BaseUrl` to the exact URL printed when `RaceDay.Api` starts, including trailing slash. For example `https://localhost:7123/`. When using Docker, use an address reachable from the container and configure the API for HTTP in a local development network or use a trusted HTTPS certificate.

## Run locally
From the repository root:

```bash
dotnet restore RaceDay.sln
dotnet build RaceDay.sln --configuration Release
dotnet test RaceDay.Tests/RaceDay.Tests.csproj --configuration Release
dotnet run --project RaceDay.Api
dotnet run --project RaceDay.Mvc
```

Open the MVC URL printed by the second command. The API must be running simultaneously. Register creates a Participant. Organiser accounts must be provisioned by a trusted administrator because public registration intentionally cannot choose a privileged role.

## Docker
Build and run from the repository root:

```bash
docker build -t raceday-mvc -f Dockerfile .
docker run --rm -p 8080:8080 -e Api__BaseUrl="http://host.docker.internal:7001/" --add-host=host.docker.internal:host-gateway raceday-mvc
```

Replace port `7001` with the API's reachable HTTP port. Ensure the API listens on an address reachable from Docker; localhost inside the container refers to the container itself. On Docker Desktop, `host.docker.internal` resolves to the host. Linux may require the supplied `--add-host` option.

## Azure Blob Storage configuration
The API now includes authenticated image endpoints: `POST /api/media/profile` for the current user and `POST /api/media/events/{eventId}/banner` for the event owner. The API validates JPG/PNG/WEBP files up to 5 MB, uploads them to `profile-images` or `event-banners`, and saves their blob URLs in SQL. Apply `docs/Part3_ImageStorage_Migration.sql` once to an existing database (it adds nullable columns without dropping data). Set `AzureBlobStorage__ConnectionString` as an environment variable or user-secret; do not commit the storage key. The MVC profile and event category pages include upload forms that call these API endpoints. Azure containers are created by the API with blob read access so the returned URLs can display in the browser.

The API event update/cancel and banner upload endpoints enforce organiser ownership. The current Part 2 API source was not compiled in the environment used to assemble this bundle. Run the commands above and use the CI workflow to verify it.

## Evidence still required for submission
- A real successful `dotnet build` and `dotnet test` run / green GitHub Actions check.
- Screenshots of both role dashboards, event enrolment and result capture.
- A real unlisted YouTube demonstration URL added here after recording. Do not invent a link or claim a demo has been recorded.
- At least 20 meaningful commits made as actual work is completed; this ZIP cannot manufacture authentic commit history.
